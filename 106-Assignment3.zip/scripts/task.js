// create the task class
class Task {
    constructor(title,imp,dueDate,location,priority,color,collaborator,description){
        this.title=title;
        this.important=imp;
        this.dueDate=dueDate;
        this.location=location;
        this.priority=priority;
        this.color=color;
        this.collaborator=collaborator;
        this.description=description;

        this.name="Krystle";
    }
}